
class Cat(object):
    
    def __init__(self, name, legs):
        self.name = name
        self.legs = legs

    def running_speed(self,):
        if self.legs>4 :
            return 20
        else:
            return 40

def running_competition(*list_of_animals):
    if len(list_of_animals)<1:
        print("No one Running")
        return
    fastest_animal = list_of_animals[0]
    maxspeed = fastest_animal.running_speed()
    for animal in list_of_animals[1:]:
        runspeed =  animal.running_speed()
        if runspeed > maxspeed:
            fastest_animal = animal
            maxspeed = runspeed
    print("winner is {0} with {1} Km/h".format(fastest_animal.name,maxspeed))

running_competition(Cat('cat_a',4),Cat('cat_b',3))

class Fish(object):
    
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def swim_speed(self):
        if self.age < 2:
            return 40
        else:
            return 60

# to let our fish to participate in tournament it should have similar interface as 
# cat, we can also do this by using an adaptor class RunningFish

class RunningFish(object):
    def __init__(self, fish):
        self.legs = 4 # dummy
        self.fish = fish

    def running_speed(self):
        return self.fish.swim_speed()

    def __getattr__(self, attr):
        return getattr(self.fish,attr)

running_competition(Cat('cat_a',4),
                    Cat('cat_b',3),
                    RunningFish(Fish('nemo',3)),
                    RunningFish(Fish('dollar',1)))
