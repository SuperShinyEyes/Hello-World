import weakref


class Link(object):

    def __init__(self, ref, text, image_path=None):
        self.ref = ref
        if image_path:
            self.image = BrowserImage(image_path)
        else:
            self.image = None
        self.text = text

    def __str__(self):
        if not self.image:
            return "<Link (%s)>" % self.text
        else:
            return "<Link (%s,%s)>" % (self.text, str(self.image))


class BrowserImage(object):
    _resources = weakref.WeakValueDictionary()

    def __new__(cls, location):
        image = BrowserImage._resources.get(location, None)
        if not image:
            image = object.__new__(cls)
            BrowserImage._resources[location] = image
            image.__init(location)
        return image

    def __init(self, location):
        self.location = location
        # self.content = load picture into memory

    def __str__(self,):
        return "<BrowserImage(%s)>" % self.location

icon = Link("www.pythonunlocked.com", "python unlocked book", "logo.png")
footer_icon = Link("www.pythonunlocked.com/#bottom", "Author Arun", "logo.png")
twitter_top_header_icon = Link(
    "www.twitter.com/pythonunlocked", "visit twitter", "logo.png")

print(icon, footer_icon, twitter_top_header_icon)
