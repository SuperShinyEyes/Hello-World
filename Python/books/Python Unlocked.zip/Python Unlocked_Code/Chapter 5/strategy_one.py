TAX_PERCENT = .12

def tax_simple(billamount):
    return billamount * TAX_PERCENT

def tax_actual(billamount):
    if billamount < 500:
        return billamount * (TAX_PERCENT//2)
    else:
        return billamount * TAX_PERCENT

tax_cal = tax_simple
print(tax_cal(400),tax_cal(700))

tax_cal = tax_actual
print(tax_cal(400),tax_cal(700))
