import os
import abc
import six


class Animal(six.with_metaclass(abc.ABCMeta, object)):

    """ clients only need to know this interface"""

    @abc.abstractmethod
    def sound(self,):
        pass

# variations of interface


class Dog(Animal):

    """ first type of object conforming to interface"""

    def __init__(self, name):
        self.name = name
        self.breed = 'unknown'

    def sound(self,):
        print("bark bark")


class Cat(Animal):

    """ second variation of class conforming to Animal Interface"""

    def __init__(self, name):
        self.name = name

    def sound(self,):
        print("meow meow")

# abstract factories for creating classes


class AbstractAnimalFactory(object):

    def get_animal(self, animal_species, name):
        if animal_species == 'DOG':
            return Dog(name)
        elif animal_species == 'CAT':
            return Cat(name)


if __name__ == '__main__':
    af = AbstractAnimalFactory()
    dog = af.get_animal('DOG', 'bulli')
    cat = af.get_animal('CAT', 'kitty')
    dog.sound()
    cat.sound()
