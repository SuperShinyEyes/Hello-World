class Leg(object):
    def __init__(self,name):
        self.name = name

    def forward(self):
        print("{0},".format(self.name), end="")


class WalkingDrone(object):
    
    def __init__(self, name):
        self.name = name
        self.frontrightleg = Leg('Front Right Leg')
        self.frontleftleg = Leg('Front Left Leg')
        self.backrightleg = Leg('Back Right Leg')
        self.backleftleg = Leg('Back Left Leg')

    def walk(self):
        print("\nmoving ",end="")
        self.frontrightleg.forward()
        self.backleftleg.forward()
        print("\nmoving ",end="")
        self.frontleftleg.forward()
        self.backrightleg.forward()

    def run(self):
        print("\nmoving ",end="")
        self.frontrightleg.forward()
        self.frontleftleg.forward()
        print("\nmoving ",end="")
        self.backrightleg.forward()
        self.backleftleg.forward()

wd = WalkingDrone("RoboDrone" )
print("\nwalking")
wd.walk()
print("\nrunning")
wd.run()
